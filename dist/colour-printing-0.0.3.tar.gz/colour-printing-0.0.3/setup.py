import setuptools

setuptools.setup(
    name="colour-printing",
    version="0.0.3",
    author="faithforus",
    author_email="ljunf817@163.com",
    description="colour-printing",
    url="https://github.com/Faithforus/Colour-printing",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
