from .log import ColourPrint, Switch
