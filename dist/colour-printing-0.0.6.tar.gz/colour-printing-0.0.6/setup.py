import setuptools

setuptools.setup(
    name="colour-printing",
    version="0.0.6",
    author="faithforus",
    author_email="ljunf817@163.com",
    description="colour-printing",
    long_description="以不同颜色区分终端输出信息类型，标识出重要信息",
    keywords="python package print",
    url="https://github.com/Faithforus/Colour-printing",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
