class Switch:
    signal: bool = True  # 总开关
    filter: list = []  # 过滤,指定那些种类不打印
