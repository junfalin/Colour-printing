from colour_printing.log import ColourPrint
from colour_printing.switch import Switch

