from colour_printing.pen_box import ColourPrint
from colour_printing.switch import Switch
from colour_printing.style import Mode, Back, Fore
