name = "printing"
from .log import ColourPrint, Switch
