import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="printing",
    version="0.0.1",
    author="faithforus",
    author_email="ljunf817@163.com",
    description="colour-printing",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Faithforus/Colour-printing",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
