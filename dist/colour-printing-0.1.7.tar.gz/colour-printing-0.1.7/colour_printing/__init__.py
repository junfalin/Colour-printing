from colour_printing.pen_box import ColourPrint
from colour_printing.switch import Switch

